rm(list = ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()
library(readr)
library(dplyr)
library(tidyr)
#install.packages("broom")
library(broom)
#install.packages("modelsummary")
library(modelsummary)
#install.packages("stargazer")
library(stargazer)
data <- read.csv("data.csv")
data$Date <- as.Date(data$Date)
market_return <- read.csv("factors_daily.csv")
market_return$Date <- as.Date(as.character(market_return$Date), format = "%Y%m%d")
market_return$Date <- as.Date(market_return$Date)
tickers <- c("AMZN", "MSFT", "NVDA", "JPM")
data_filtered <- data %>%
  filter(Symbol %in% tickers) %>%
  arrange(Symbol, Date)

data_filtered <- data_filtered %>%
  group_by(Symbol) %>%
  mutate(stock_return = log(`Adj.Close` / lag(`Adj.Close`))) %>%
  ungroup()

market_return <- market_return %>%
  mutate(Date = as.Date(Date)) %>%
  rename(market_return = Mkt.RF) %>%
  select(Date, market_return)

data_merged <- data_filtered %>%
  left_join(market_return, by = "Date") %>%
  filter(!is.na(stock_return) & !is.na(market_return))

firm_betas <- data_merged %>%
  group_by(Symbol) %>%
  do(tidy(lm(stock_return ~ market_return, data = .))) %>%
  select(Symbol, term, estimate) %>%
  pivot_wider(names_from = term, values_from = estimate) %>%
  rename(alpha = `(Intercept)`, beta = market_return)
data_merged <- left_join(data_merged, firm_betas, by = "Symbol")

data_merged <- data_merged %>%
  mutate(expected_return = alpha + beta * market_return,
         abnormal_return = stock_return - expected_return)

data_merged <- data_merged %>%
  mutate(abs_ar = abs(abnormal_return))
#colnames(data_merged)

#########DATA VISUALIZATION 
# Plotting histograms of abnormal returns for each company
ggplot(data_merged, aes(x = abnormal_return, fill = Symbol)) +
  geom_histogram(bins = 30, alpha = 0.6, position = "identity") +
  facet_wrap(~ Symbol, scales = "free_y") +
  labs(title = "Distribution of Abnormal Returns by Company",
       x = "Abnormal Return",
       y = "Frequency") +
  theme_minimal()

news_summary <- data_filtered %>%
  select(Symbol, starts_with("News")) %>%
  summarise(across(starts_with("News"), sum, na.rm = TRUE))
print(news_summary)

library(moments)
stock_return_summary <- data_merged %>%
  filter(Symbol %in% c("MSFT", "NVDA", "AMZN", "JPM")) %>%
  group_by(Symbol) %>%
  summarise(
    mean_return = mean(stock_return, na.rm = TRUE),
    median_return = median(stock_return, na.rm = TRUE),
    sd_return = sd(stock_return, na.rm = TRUE),
    skewness_return = skewness(stock_return, na.rm = TRUE),
    kurtosis_return = kurtosis(stock_return, na.rm = TRUE),
    n = n()
  )

# Print stock return summary
print(stock_return_summary)

ggplot(data_merged, aes(x = stock_return, fill = Symbol)) +
  geom_histogram(bins = 30, alpha = 0.6, position = "identity") +
  facet_wrap(~ Symbol, scales = "free_y") +
  labs(title = "Distribution of Stock Returns by Company",
       x = "Stock Return",
       y = "Frequency") +
  theme_minimal()

# AMZN abnormal returns
amzn_abnormal_returns <- data_merged %>%
  filter(Symbol == "AMZN") %>%
  pull(abnormal_return)

# JPM abnormal returns
jpm_abnormal_returns <- data_merged %>%
  filter(Symbol == "JPM") %>%
  pull(abnormal_return)

# MSFT abnormal returns
msft_abnormal_returns <- data_merged %>%
  filter(Symbol == "MSFT") %>%
  pull(abnormal_return)

# NVDA abnormal returns
nvda_abnormal_returns <- data_merged %>%
  filter(Symbol == "NVDA") %>%
  pull(abnormal_return)

# Perform Shapiro-Wilk Test for normality
shapiro_amzn <- shapiro.test(amzn_abnormal_returns)
shapiro_jpm <- shapiro.test(jpm_abnormal_returns)
shapiro_msft <- shapiro.test(msft_abnormal_returns)
shapiro_nvda <- shapiro.test(nvda_abnormal_returns)

# Results
shapiro_amzn
shapiro_jpm
shapiro_msft
shapiro_nvda


#####1st hypothesis ###############
####H1: Abnormal returns are significantly different from zero on news days (event study basis).

summary(lm(abs_ar ~ `News...Volume` , data = data_merged))


#####Code for each individual 4 companies

firms <- unique(data_merged$Symbol)
models <- list()

for (firm in firms) {
  firm_data <- data_merged %>% filter(Symbol == firm)
  
  models[[firm]] <- lm(abnormal_return ~ 
                         `News...Layoffs` + 
                         `News...Corporate.Earnings` + 
                         `News...Mergers...Acquisitions` + 
                         `News...Product.Recalls` + 
                         `News...Personnel.Changes` + 
                         `News...Store.Openings` + 
                         `News...Dividends` + 
                         `News...Analyst.Comments` + 
                         `News...New.Products` + 
                         `News...Stock.Rumors` + 
                         `News...Adverse.Events`,
                       data = firm_data)
}

stargazer(models$MSFT, models$JPM, models$NVDA, models$AMZN,
          type = "text",   # "latex" or "html" for publication
          title = "Impact of News on Abnormal Returns",
          column.labels = c("MSFT", "JPM", "NVDA", "AMZN"),
          covariate.labels = c(
            "Layoffs",
            "Earnings",
            "M&A",
            "Recalls",
            "Personnel Changes",
            "Store Openings",
            "Dividends",
            "Analyst Comments",
            "New Products",
            "Rumors",
            "Adverse Events"
          ),
          omit.stat = c("f", "ser", "adj.rsq"),  # Hide clutter
          digits = 3,
          star.cutoffs = c(0.1, 0.05, 0.01),
          notes.align = "l",
          no.space = TRUE,
          out = "table.html"
         )


############CAR MSFT and JPM
# --- Load necessary lib for date manipulation
library(lubridate)
event_study_firm <- function(firm, event_colname, threshold = 150) {
  library(rlang)
  
  firm_data <- data_merged %>% filter(Symbol == firm)
  
  # Step 1: Extract event dates for which event_colname >= threshold
  event_dates <- firm_data %>%
    filter(!!sym(event_colname) >= threshold) %>%
    pull(Date)
  
  # Step 2: Create empty df to collect results
  results <- data.frame()
  
  # Step 3: Loop through each event
  for (event_date in event_dates) {
    
    # Define estimation and event windows
    est_start <- event_date - 70
    est_end <- event_date - 11
    evt_start <- event_date - 3
    evt_end <- event_date + 3
    
    est_data <- firm_data %>%
      filter(Date >= est_start & Date <= est_end)
    
    evt_data <- firm_data %>%
      filter(Date >= evt_start & Date <= evt_end)
    
    # Ensure enough observations
    if (nrow(est_data) < 40 | nrow(evt_data) < 3) {
      next
    }
    
    # Estimate market model
    model <- lm(stock_return ~ market_return, data = est_data)
    alpha <- coef(model)[1]
    beta <- coef(model)[2]
    
    # Step 4: Compute abnormal return and event_day
    evt_data <- evt_data %>%
      mutate(expected_return = alpha + beta * market_return,
             abnormal_return = stock_return - expected_return,
             event_day = as.integer(Date - event_date))
    
    results <- bind_rows(results, evt_data %>% select(Date, event_day, abnormal_return))
  }
  
  return(results)
}
msft_events <- event_study_firm("MSFT", "News...Corporate.Earnings")
jpm_events <- event_study_firm("JPM", "News...Corporate.Earnings", threshold = 100)
nvda_events_div <- event_study_firm("NVDA", "News...Dividends", threshold = 1)
nvda_events_personnel <- event_study_firm("NVDA", "News...Personnel.Changes", threshold = 10)
amzn_events_comments <- event_study_firm("AMZN", "News...Analyst.Comments", threshold = 30)

avg_msft <- msft_events %>%
  group_by(event_day) %>%
  summarise(
    mean_ar = mean(abnormal_return, na.rm = TRUE),
    se = sd(abnormal_return, na.rm = TRUE) / sqrt(n()),
    car = cumsum(mean_ar),
    .groups = "drop"
  )

print(avg_msft)

msft_events %>%
  filter(event_day %in% c(-1, 0, 1)) %>%
  pull(abnormal_return) %>%
  t.test(mu = 0)
jpm_events %>%
  filter(event_day %in% c(-1, 0, 1)) %>%
  pull(abnormal_return) %>%
  t.test(mu = 0)
nvda_events_div %>%
  filter(event_day %in% c(-1, 0, 1)) %>%
  pull(abnormal_return) %>%
  t.test(mu = 0)
nvda_events_personnel %>%
  filter(event_day %in% c(-1, 0, 1)) %>%
  pull(abnormal_return) %>%
  t.test(mu = 0)
amzn_events_comments %>%
  filter(event_day %in% c(-1, 0, 1)) %>%
  pull(abnormal_return) %>%
  t.test(mu = 0)

calculate_car <- function(event_data) {
  event_data %>%
    group_by(event_day) %>%
    summarise(
      mean_ar = mean(abnormal_return, na.rm = TRUE),
      se = sd(abnormal_return, na.rm = TRUE) / sqrt(n()),
      car = cumsum(mean_ar),  # Cumulative sum of abnormal returns
      .groups = "drop"
    )
}

# Calculate CAR for each firm
msft_car <- calculate_car(msft_events)
jpm_car <- calculate_car(jpm_events)
nvda_car_div <- calculate_car(nvda_events_div)
nvda_car_personnel <- calculate_car(nvda_events_personnel)
amzn_car <- calculate_car(amzn_events_comments)

# Combine all CAR data into a single data frame for plotting
car_data <- bind_rows(
  msft_car %>% mutate(firm = "MSFT"),
  jpm_car %>% mutate(firm = "JPM"),
  nvda_car_div %>% mutate(firm = "NVDA (Dividends)"),
  nvda_car_personnel %>% mutate(firm = "NVDA (Personnel)"),
  amzn_car %>% mutate(firm = "AMZN (Analyst Comments)")
)


###################PLOTS####################

# Plot CAR for all firms
library(ggplot2)
library(dplyr)
library(lubridate)

ggplot(car_data, aes(x = event_day, y = car, color = firm, group = firm)) +
  geom_line() + 
  geom_point() +
  labs(
    title = "Cumulative Abnormal Returns (CAR) by Firm",
    x = "Event Day",
    y = "Cumulative Abnormal Return (CAR)",
    color = "Firm"
  ) +
  theme_minimal() +
  theme(legend.position = "top")

############MSFT ###

msft_data <- data_merged %>%
  filter(Symbol == "MSFT") %>%
  select(Date, `News...Corporate.Earnings`) %>%
  mutate(Year = year(Date), Month = month(Date, label = TRUE))

# Aggregate data by Year and Month, summing the news volume
msft_monthly <- msft_data %>%
  group_by(Year, Month) %>%
  summarise(total_news_volume = sum(`News...Corporate.Earnings`, na.rm = TRUE))

# Plotting the data
ggplot(msft_monthly, aes(x = Month, y = total_news_volume, color = factor(Year), group = Year)) +
  geom_line() +
  geom_point() +
  labs(title = "Microsoft Corporate Earnings News Volume (2020-2022)", 
       x = "Month", 
       y = "Volume of Corporate Earnings News", 
       color = "Year") +
  scale_x_discrete(limits = unique(msft_monthly$Month)) +  # Ensure only available months are plotted
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

###########JPM
jpm_data <- data_merged %>%
  filter(Symbol == "JPM") %>%
  select(Date, `News...Corporate.Earnings`) %>%
  mutate(Year = year(Date), Month = month(Date, label = TRUE))

# Aggregate data by Year and Month, summing the news volume
jpm_monthly <- jpm_data %>%
  group_by(Year, Month) %>%
  summarise(total_news_volume = sum(`News...Corporate.Earnings`, na.rm = TRUE))

# Plotting the data
ggplot(jpm_monthly, aes(x = Month, y = total_news_volume, color = factor(Year), group = Year)) +
  geom_line() +
  geom_point() +
  labs(title = "JPMorgan Corporate Earnings News Volume (2020-2022)", 
       x = "Month", 
       y = "Volume of Corporate Earnings News", 
       color = "Year") +
  scale_x_discrete(limits = unique(jpm_monthly$Month)) +  # Ensure only available months are plotted
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rot

###NVDA
nvda_personnel_data <- data_merged %>%
  filter(Symbol == "NVDA") %>%
  select(Date, `News...Personnel.Changes`) %>%
  mutate(Year = year(Date), Month = month(Date, label = TRUE))

# Aggregate data by Year and Month, summing the news volume for Personnel Changes
nvda_personnel_monthly <- nvda_personnel_data %>%
  group_by(Year, Month) %>%
  summarise(total_news_volume = sum(`News...Personnel.Changes`, na.rm = TRUE))

# Plotting the data for Personnel Changes
ggplot(nvda_personnel_monthly, aes(x = Month, y = total_news_volume, color = factor(Year), group = Year)) +
  geom_line() +
  geom_point() +
  labs(title = "NVIDIA Personnel Changes News Volume (2020-2022)", 
       x = "Month", 
       y = "Volume of Personnel Changes News", 
       color = "Year") +
  scale_x_discrete(limits = unique(nvda_personnel_monthly$Month)) +  # Ensure only available months are plotted
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))




#####AMZN

# Prepare Amazon data for Analyst Comments
amzn_comments_data <- data_merged %>%
  filter(Symbol == "AMZN") %>%
  select(Date, `News...Analyst.Comments`) %>%
  mutate(Year = year(Date), Month = month(Date, label = TRUE))

# Aggregate data by Year and Month, summing the news volume for Analyst Comments
amzn_comments_monthly <- amzn_comments_data %>%
  group_by(Year, Month) %>%
  summarise(total_news_volume = sum(`News...Analyst.Comments`, na.rm = TRUE))

# Plotting the data for Analyst Comments
ggplot(amzn_comments_monthly, aes(x = Month, y = total_news_volume, color = factor(Year), group = Year)) +
  geom_line() +
  geom_point() +
  labs(title = "Amazon Analyst Comments News Volume (2020-2022)", 
       x = "Month", 
       y = "Volume of Analyst Comments News", 
       color = "Year") +
  scale_x_discrete(limits = unique(amzn_comments_monthly$Month)) +  # Ensure only available months are plotted
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # Rotate x-axis labels for readability
